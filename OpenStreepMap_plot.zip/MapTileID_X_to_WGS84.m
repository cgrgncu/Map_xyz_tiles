%**************************************************************************
%   Name: MapTileID_X_to_WGS84.m v20230314a
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20230314a
%   Description: ��XWGS84�n�׹������Ͽj�C
%   REF:https://wiki.openstreetmap.org/wiki/Slippy_map_tilenames#C#
%   �I�s�覡:
%       Longitude_in_degrees=MapTileID_X_to_WGS84(53,6)
%       ���G: Longitude_in_degrees = 118.1250
%**************************************************************************
function Longitude_in_degrees=MapTileID_X_to_WGS84(MapTileID_X,MapTileID_Z)
    % disp(['�ؼ�TileID_X = ',num2str(MapTileID_X)])
    % disp(['�ؼ�TileID_Z = ',num2str(MapTileID_Z)])
    Longitude_in_degrees=MapTileID_X/2^MapTileID_Z*360-180;   
    % disp(['�ؼйϿj�����g��[��] = ',num2str(Longitude_in_degrees)])
end