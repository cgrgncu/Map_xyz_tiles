clear;clc;close all
%--------------------------------------------------------------------------
% �u����HTTPS
% �D�{�� = curl.exe
% �w�R�B��S���i�׻��� = �u"-s"�v�Ρu"--silent"�v
% ���ճs�u�欰���O�ɳ]�w�A���� = �u"--connect-timeout" "10"�v-> �]�w��10�����d��
% ���curl�B��̪����ɶ��A�W�L�h�j��_ =�u"--max-time" "10"�v-> �]�w��10�����d��
% �U�����ɮ� = �u"-o" "D:\123.txt"�v�Ρu"--output" "D:\123.txt"�v
% �g�J�ɮ׮ɦ��ݭn�N�ۤv�إ߸�Ƨ��A�U���� = �u--create-dirs�v
%--retry 3 --retry-delay 10
% [aa,aa_char]=system('curl.exe "-s" "--connect-timeout" "5" "--max-time" "100" "-o" "./openstreetmap/6/53/27.png" "--create-dirs" "https://tile.openstreetmap.org/6/53/27.png"');
disp('--')
%--------------------------------------------------------------------------
target_MapTileID_Z=15;    
target_left_Longitude_in_degrees=121.542300;
target_right_Longitude_in_degrees=121.552900;
    disp(['�ؼаϰ�g��[��](�����,�S���) = (',num2str(target_left_Longitude_in_degrees),',',num2str(target_right_Longitude_in_degrees),')'])
    %--
    target_left_MapTileID_X=WGS84_to_MapTileID_X(target_left_Longitude_in_degrees,target_MapTileID_Z);
    target_left_MapTile_Longitude_in_degrees=MapTileID_X_to_WGS84(target_left_MapTileID_X,target_MapTileID_Z);
    disp(['�����̥��䪺�Ͽj�s��(����ɸg��[��]) = X#',num2str(target_left_MapTileID_X),'(Left:',num2str(target_left_MapTile_Longitude_in_degrees),')'])
    %--
    target_right_MapTileID_X=WGS84_to_MapTileID_X(target_right_Longitude_in_degrees,target_MapTileID_Z);
    target_right_MapTile_Longitude_in_degrees=MapTileID_X_to_WGS84(target_right_MapTileID_X+1,target_MapTileID_Z);    
    disp(['�����̥k�䪺�Ͽj�s��(�k��ɸg��[��]) = X#',num2str(target_right_MapTileID_X),'(Right:',num2str(target_right_MapTile_Longitude_in_degrees),')'])
    %--    
target_top_Latitude_in_degrees=25.181000;
target_bottom_Latitude_in_degrees=25.167800;
    disp(['�ؼаϰ�n��[��](�W���,�U���) = (',num2str(target_top_Latitude_in_degrees),',',num2str(target_bottom_Latitude_in_degrees),')'])
    %--
    target_top_MapTileID_Y=WGS84_to_MapTileID_Y(target_top_Latitude_in_degrees,target_MapTileID_Z);
    target_top_MapTile_Latitude_in_degrees=MapTileID_Y_to_WGS84(target_top_MapTileID_Y,target_MapTileID_Z);
    disp(['�����̤W�誺�Ͽj�s��(�W��ɽn��[��]) = Y#',num2str(target_top_MapTileID_Y),'(Top:',num2str(target_top_MapTile_Latitude_in_degrees),')'])
    %--
    target_bottom_MapTileID_Y=WGS84_to_MapTileID_Y(target_bottom_Latitude_in_degrees,target_MapTileID_Z);
    target_bottom_MapTile_Latitude_in_degrees=MapTileID_Y_to_WGS84(target_bottom_MapTileID_Y,target_MapTileID_Z);   
    disp(['�����̥k�䪺�Ͽj�s��(�k��ɸg��[��]) = Y#',num2str(target_bottom_MapTileID_Y),'(Bottom:',num2str(target_bottom_MapTile_Latitude_in_degrees),')'])
    %--
    % �U��
    disp('�U���Ͽj...�}�l')
    z_index=target_MapTileID_Z;
    for x_index=target_left_MapTileID_X:target_right_MapTileID_X
        for y_index=target_top_MapTileID_Y:target_bottom_MapTileID_Y
            openstreetmap_png_src=['https://tile.openstreetmap.org/',num2str(z_index),'/',num2str(x_index),'/',num2str(y_index),'.png'];
            openstreetmap_png_save_path=openstreetmap_png_src;
            openstreetmap_png_save_path=strrep(openstreetmap_png_save_path,'https://tile.','');
            openstreetmap_png_save_path=strrep(openstreetmap_png_save_path,'.org','');
            disp(openstreetmap_png_save_path)
            if ~exist(openstreetmap_png_save_path,'file')
                system(['curl.exe "--connect-timeout" "5" "--max-time" "100" "-o" "./',openstreetmap_png_save_path,'" "--create-dirs" "',openstreetmap_png_src,'"']);
            end
        end
    end
    %--
    disp('�U���Ͽj...����!')
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
% �X�ֹϿj�ÿ�X
    z_index=target_MapTileID_Z;
    RGB_xy_cell=cell(target_right_MapTileID_X,target_bottom_MapTileID_Y);
    X_range=target_left_MapTileID_X:target_right_MapTileID_X;
    Y_rnage=target_top_MapTileID_Y:target_bottom_MapTileID_Y;
    for x_index=X_range
        for y_index=Y_rnage
            openstreetmap_png_src=['https://tile.openstreetmap.org/',num2str(z_index),'/',num2str(x_index),'/',num2str(y_index),'.png'];
            openstreetmap_png_save_path=openstreetmap_png_src;
            openstreetmap_png_save_path=strrep(openstreetmap_png_save_path,'https://tile.','');
            openstreetmap_png_save_path=strrep(openstreetmap_png_save_path,'.org','');
            disp(openstreetmap_png_save_path)
            [temp_X,temp_map]=imread(openstreetmap_png_save_path); 
            RGB_xy_cell{x_index,y_index}=ind2rgb(temp_X,temp_map);        
        end
    end
    my_RGB_xy_cell=RGB_xy_cell(X_range,Y_rnage)';        
    all_RGB_data=cell2mat(my_RGB_xy_cell);
    % imshow(all_RGB_data)    
    %--
    % �s��	
    output_file_name='output.png';
    imwrite(all_RGB_data,output_file_name) 
    % �w��
    imshow(output_file_name)
%--------------------------------------------------------------------------