%**************************************************************************
%   Name: MapTileID_Y_to_WGS84.m v20230314a
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20230314a
%   Description: ��XWGS84�n�׹������Ͽj�C
%   REF:https://wiki.openstreetmap.org/wiki/Slippy_map_tilenames#C#
%   �I�s�覡:
%       Latitude_in_degrees=MapTileID_Y_to_WGS84(27,6)
%       ���G: Longitude_in_degrees = 118.1250
%**************************************************************************
function Latitude_in_degrees=MapTileID_Y_to_WGS84(MapTileID_Y,MapTileID_Z)
    % disp(['�ؼ�TileID_X = ',num2str(MapTileID_Y)])
    % disp(['�ؼ�TileID_Z = ',num2str(MapTileID_Z)])
    Latitude_in_degrees=(180.0/pi*atan(sinh(pi-2*pi*MapTileID_Y/2^MapTileID_Z)));
    % disp(['�ؼйϿj�����g��[��] = ',num2str(Latitude_in_degrees)])
end