%**************************************************************************
%   Name: WGS84_to_MapTileID_Y.m v20230314a
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20230314a
%   Description: ��XWGS84�n�׹������Ͽj�C
%   REF:https://wiki.openstreetmap.org/wiki/Slippy_map_tilenames#C#
%   �I�s�覡:
%       MapTileID_Y=WGS84_to_MapTileID_Y(22,6)
%       ���G: MapTileID_Y = 27
%**************************************************************************
function MapTileID_Y=WGS84_to_MapTileID_Y(Latitude_in_degrees,MapTileID_Z)
    % disp(['�ؼнn�׫�[��] = ',num2str(Latitude_in_degrees)])
    % disp(['�ؼ�TileID_Z = ',num2str(MapTileID_Z)])
    MapTileID_Y=floor((1-log(tand(Latitude_in_degrees)+(1/cosd(Latitude_in_degrees)))/pi)/2*2^MapTileID_Z);    
    % disp(['�ؼЮy���I���ݹϿjID(Y,Z) = (',num2str(Latitude_in_degrees),',',num2str(MapTileID_Z),')'])
end