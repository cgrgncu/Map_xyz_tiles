clear;clc
%--------------------------------------------------------------------------
% �d�߸g�n���ݩ���@�ӹϿj
target_MapTileID_Z=7;
target_point_Longitude_in_degrees=119;
target_point_Latitude_in_degrees=22;
    disp(['�ؼЮy���I(�g��[��],�n��[��]) = (',num2str(target_point_Longitude_in_degrees),',',num2str(target_point_Latitude_in_degrees),')'])
    target_MapTileID_X=WGS84_to_MapTileID_X(target_point_Longitude_in_degrees,target_MapTileID_Z);
    target_MapTileID_Y=WGS84_to_MapTileID_Y(target_point_Latitude_in_degrees,target_MapTileID_Z);
	disp(['�ؼЮy���I���ݹϿjID(X,Y,Z) = (',num2str(target_MapTileID_X),',',num2str(target_MapTileID_Y),',',num2str(target_MapTileID_Z),')'])

% �Ͽj�d�߸g�n�׽d��
search_MapTileID_X=target_MapTileID_X;
search_MapTileID_Y=target_MapTileID_Y;
search_MapTileID_Z=target_MapTileID_Z;
    disp(['�d�߹ϿjID(X,Y,Z) = (',num2str(search_MapTileID_X),',',num2str(search_MapTileID_Y),',',num2str(search_MapTileID_Z),')'])
    MapTile_left_Longitude_in_degrees=MapTileID_X_to_WGS84(search_MapTileID_X,search_MapTileID_Z);
    MapTile_right_Longitude_in_degrees=MapTileID_X_to_WGS84(search_MapTileID_X+1,search_MapTileID_Z);
    
    MapTile_top_Longitude_in_degrees=MapTileID_Y_to_WGS84(search_MapTileID_Y,search_MapTileID_Z);
    MapTile_bottom_Longitude_in_degrees=MapTileID_Y_to_WGS84(search_MapTileID_Y+1,search_MapTileID_Z);
    disp(['�Ͽj�����g�׽d��(Left,Right) = (',num2str(MapTile_left_Longitude_in_degrees),',',num2str(MapTile_right_Longitude_in_degrees),')'])
    disp(['�Ͽj�����n�׽d��(Top,Bottom) = (',num2str(MapTile_top_Longitude_in_degrees),',',num2str(MapTile_bottom_Longitude_in_degrees),')'])
%--------------------------------------------------------------------------