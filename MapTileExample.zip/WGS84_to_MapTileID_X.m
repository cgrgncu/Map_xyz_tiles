%**************************************************************************
%   Name: WGS84_to_MapTileID_X.m v20230314a
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20230314a
%   Description: ��XWGS84�g�׹������Ͽj�C
%   REF:https://wiki.openstreetmap.org/wiki/Slippy_map_tilenames#C#
%   �I�s�覡:
%       MapTileID_X=WGS84_to_MapTileID_X(119,6)
%       ���G: MapTileID_X = 53
%**************************************************************************
function MapTileID_X=WGS84_to_MapTileID_X(Longitude_in_degrees,MapTileID_Z)
    % disp(['�ؼиg��[��] = ',num2str(Longitude_in_degrees)])
    % disp(['�ؼ�TileID_Z = ',num2str(MapTileID_Z)])
    MapTileID_X=floor(((Longitude_in_degrees+180)/360)*2^MapTileID_Z);
    % disp(['�ؼЮy���I���ݹϿjID(X,Z) = (',num2str(Longitude_in_degrees),',',num2str(MapTileID_Z),')'])
end